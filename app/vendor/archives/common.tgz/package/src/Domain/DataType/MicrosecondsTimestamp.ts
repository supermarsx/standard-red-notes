export type MicrosecondsTimestamp = number
